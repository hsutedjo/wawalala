﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Reflection;
using System.Runtime.Remoting.Lifetime;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace TH05_Heidy_Mudita_S
{
    public partial class Form_BlinkShop : Form
    {
        DataTable dtProdukSimpan = new DataTable();
        DataTable dtProdukTampil = new DataTable();
        DataTable dtCategory = new DataTable();
        string IDsementara;
        string category;
        string letters = "qwertyuioplkjhgfdsazxcvbnm~`!@#$%^&*()_+-={}[]|:;',./<>?";
        public Form_BlinkShop()
        {
            InitializeComponent();
        }

        private void Form_BlinkShop_Load(object sender, EventArgs e)
        {
            dtProdukSimpan.Columns.Add("ID Product");
            dtProdukSimpan.Columns.Add("Nama Product");
            dtProdukSimpan.Columns.Add("Harga");
            dtProdukSimpan.Columns.Add("Stock");
            dtProdukSimpan.Columns.Add("ID Category");
            dtProdukSimpan.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukSimpan.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukSimpan.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukSimpan.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukSimpan.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukSimpan.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukSimpan.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukSimpan.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2");
            dtProdukTampil.Columns.Add("ID Product");
            dtProdukTampil.Columns.Add("Nama Product");
            dtProdukTampil.Columns.Add("Harga");
            dtProdukTampil.Columns.Add("Stock");
            dtProdukTampil.Columns.Add("ID Category");
            dtProdukTampil.Rows.Add("J001", "Jas Hitam", "100000", "10", "C1");
            dtProdukTampil.Rows.Add("T001", "T-Shirt Black Pink", "70000", "20", "C2");
            dtProdukTampil.Rows.Add("T002", "T-Shirt Obsessive", "75000", "16", "C2");
            dtProdukTampil.Rows.Add("R001", "Rok Mini", "82000", "26", "C3");
            dtProdukTampil.Rows.Add("J002", "Jeans Biru", "90000", "5", "C4");
            dtProdukTampil.Rows.Add("C001", "Celana Pendek Coklat", "60000", "11", "C4");
            dtProdukTampil.Rows.Add("C002", "Cawat Blink-Blink", "1000000", "1", "C5");
            dtProdukTampil.Rows.Add("R002", "Rocca Shirt", "50000", "8", "C2"); dtCategory.Columns.Add("ID Category");
            dtCategory.Columns.Add("Nama Category");
            dtCategory.Rows.Add("C1", "Jas");
            dtCategory.Rows.Add("C2", "T-Shirt");
            dtCategory.Rows.Add("C3", "Rok");
            dtCategory.Rows.Add("C4", "Celana");
            dtCategory.Rows.Add("C5", "Cawat");
            dgv_Products.DataSource = dtProdukTampil;
            dgv_Category.DataSource = dtCategory;
            for(int i = 0; i < dtCategory.Rows.Count; i++)
            {
                cbox_FilterProduct.Items.Add(dtCategory.Rows[i][1]);
                cbox_CategoryDetails.Items.Add(dtCategory.Rows[i][1]);
            }
        }

        private void btn_FilterProduct_Click(object sender, EventArgs e)
        {
            cbox_FilterProduct.Enabled = true;
        }

        private void cbox_FilterProduct_SelectedIndexChanged(object sender, EventArgs e)
        {
            dtProdukTampil.Clear();
            int index = 0;
            for (int i = 0; i < dtCategory.Rows.Count; i++)
            {                
                if (dtCategory.Rows[i][1].ToString() == cbox_FilterProduct.Text.ToString())
                {
                    index = i;
                }
             
            }
            for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
            {
                if (dtProdukSimpan.Rows[i][4] == dtCategory.Rows[index][0])
                {
                    dtProdukTampil.Rows.Add(dtProdukSimpan.Rows[i][0], dtProdukSimpan.Rows[i][1], dtProdukSimpan.Rows[i][2], dtProdukSimpan.Rows[i][3], dtProdukSimpan.Rows[i][4]);
                }
            }
        }

        private void btn_AllProduct_Click(object sender, EventArgs e)
        {
            dtProdukTampil.Clear();
            cbox_FilterProduct.Enabled = false;
            foreach(DataRow simpan in dtProdukSimpan.Rows)
            {
                dtProdukTampil.Rows.Add(simpan[0], simpan[1], simpan[2], simpan[3], simpan[4]);
            }
        }

        private void btn_AddProduct_Click(object sender, EventArgs e)
        {
            int index = 1;
            if (txtbox_NamaDetails.Text == "" || cbox_CategoryDetails.SelectedItem == null || txtbox_HargaDetails.Text == "" || txtbox_StockDetails.Text == "")
            {
                MessageBox.Show("Please fill all of the fields", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtbox_HargaDetails.Text.Any(char.IsLetter) || txtbox_StockDetails.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Harga and Stock are numbers only value", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                if (txtbox_NamaDetails.Text != "")
                {
                    int temp = 0;
                    string num = "";
                    for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                    {
                        if (dtProdukSimpan.Rows[i][0].ToString().Substring(2, 1) != "0")
                        {
                            num = dtProdukSimpan.Rows[i][0].ToString().Substring(2);
                        }
                        else
                        {
                            num = dtProdukSimpan.Rows[i][0].ToString().Substring(3);
                        }
                        if (Convert.ToInt32(num) > temp && dtProdukSimpan.Rows[i][0].ToString().Substring(0, 1).ToUpper() == txtbox_NamaDetails.Text.Substring(0, 1).ToUpper())
                        {
                            temp = Convert.ToInt32(num);
                        }
                    }
                    index = temp + 1;
                    if (index <= 9)
                    {
                        IDsementara = txtbox_NamaDetails.Text.Substring(0, 1).ToUpper() + "00" + index;
                    }
                    else if (index <= 99 && index >= 10)
                    {
                        IDsementara = txtbox_NamaDetails.Text.Substring(0, 1).ToUpper() + "0" + index;
                    }
                    else
                    {
                        IDsementara = txtbox_NamaDetails.Text.Substring(0, 1).ToUpper() + index;
                    }
                }
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == cbox_CategoryDetails.Text)
                    {
                        category = dtCategory.Rows[i][0].ToString();
                    }
                }
                dtProdukSimpan.Rows.Add(IDsementara, txtbox_NamaDetails.Text, txtbox_HargaDetails.Text, txtbox_StockDetails.Text, category);
                txtbox_NamaDetails.Clear();
                txtbox_HargaDetails.Clear();
                txtbox_StockDetails.Clear();
                cbox_CategoryDetails.Text = "";
                dtProdukTampil.Clear();
                cbox_FilterProduct.Enabled = false;
                foreach (DataRow simpan in dtProdukSimpan.Rows)
                {
                    dtProdukTampil.Rows.Add(simpan[0], simpan[1], simpan[2], simpan[3], simpan[4]);
                }
            }
        }

        private void btn_AddCategory_Click(object sender, EventArgs e)
        {
            string kode;
            bool sama = false;
            if(txtbox_NamaCategory.Text == "")
            {
                MessageBox.Show("Please enter category name", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if(txtbox_NamaCategory.Text != "")
            {
                for (int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString().ToLower() == txtbox_NamaCategory.Text.ToLower())
                    {
                        MessageBox.Show("Category already exist", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
                        sama = true;
                    }
                }
                if(sama == false)
                {
                    int temp = 0;
                    for(int i = 0; i < dtCategory.Rows.Count; i++)
                    {
                        string num = dtCategory.Rows[i][0].ToString().Substring(1);
                        if (Convert.ToInt32(num) > temp)
                        {
                            temp = Convert.ToInt32(num);
                        }
                    }
                    int index = temp + 1;
                    dtCategory.Rows.Add("C" + index, txtbox_NamaCategory.Text);
                    cbox_CategoryDetails.Items.Add(txtbox_NamaCategory.Text);
                    cbox_FilterProduct.Items.Add(txtbox_NamaCategory.Text);
                }
            }
            txtbox_NamaCategory.Clear();
        }

        private void dgv_Category_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtbox_NamaCategory.Text = dgv_Category.CurrentRow.Cells[1].Value.ToString();
        }

        private void btn_RemoveCategory_Click(object sender, EventArgs e)
        {
            string sementara = "";
            if(txtbox_NamaCategory.Text == "")
            {
                MessageBox.Show("Please select category", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                for(int i = 0; i < dtCategory.Rows.Count; i++)
                {
                    if (dtCategory.Rows[i][1].ToString() == txtbox_NamaCategory.Text)
                    {
                        sementara = dtCategory.Rows[i][0].ToString();
                        dtCategory.Rows.RemoveAt(i);
                    }
                }
                for(int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][4].ToString() == sementara)
                    {
                        dtProdukSimpan.Rows.RemoveAt(i);
                        i--;
                    }
                }
                for (int i = 0; i < cbox_CategoryDetails.Items.Count; i++)
                {
                    if (cbox_CategoryDetails.Items[i].ToString() == txtbox_NamaCategory.Text)
                    {
                        cbox_CategoryDetails.Items.RemoveAt(i);
                    }
                }
                for(int i = 0; i < cbox_FilterProduct.Items.Count; i++)
                {
                    if (cbox_FilterProduct.Items[i].ToString() == txtbox_NamaCategory.Text)
                    {
                        cbox_FilterProduct.Items.RemoveAt(i);
                    }
                }
            }
            txtbox_NamaCategory.Clear();
            dtProdukTampil.Clear();
            cbox_FilterProduct.Enabled = false;
            foreach (DataRow simpan in dtProdukSimpan.Rows)
            {
                dtProdukTampil.Rows.Add(simpan[0], simpan[1], simpan[2], simpan[3], simpan[4]);
            }
        }

        private void dgv_Products_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtbox_NamaDetails.Text = dgv_Products.CurrentRow.Cells[1].Value.ToString();
            txtbox_HargaDetails.Text = dgv_Products.CurrentRow.Cells[2].Value.ToString();
            txtbox_StockDetails.Text = dgv_Products.CurrentRow.Cells[3].Value.ToString();
            for(int i = 0; i < dtCategory.Rows.Count; i++)
            {
                if (dtCategory.Rows[i][0].ToString() == dgv_Products.CurrentRow.Cells[4].Value.ToString())
                {
                    cbox_CategoryDetails.Text = dtCategory.Rows[i][1].ToString();
                }
            }
        }

        private void btn_EditProduct_Click(object sender, EventArgs e)
        {
            if (txtbox_NamaDetails.Text == "" || txtbox_HargaDetails.Text == "" || txtbox_StockDetails.Text == "" || cbox_CategoryDetails.Text == "")
            {
                MessageBox.Show("Please choose a product from the table", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtbox_HargaDetails.Text.Any(char.IsLetter) || txtbox_StockDetails.Text.Any(char.IsLetter))
            {
                MessageBox.Show("Harga and Stock can only contain number", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else if (txtbox_StockDetails.Text == "0")
            {
                int ind = 0;
                string namabarang = dgv_Products.CurrentRow.Cells[1].Value.ToString();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][1].ToString() == namabarang)
                    {
                        ind = i;
                    }
                }
                dtProdukSimpan.Rows.RemoveAt(ind);
                dtProdukTampil.Clear();
                cbox_FilterProduct.Enabled = false;
                foreach (DataRow simpan in dtProdukSimpan.Rows)
                {
                    dtProdukTampil.Rows.Add(simpan[0], simpan[1], simpan[2], simpan[3], simpan[4]);
                }
            }
            else
            {
                int ind = 0;
                for(int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if(dgv_Products.CurrentRow.Cells[0].Value.ToString() == dtProdukSimpan.Rows[i][0].ToString())
                    {
                        ind = i;
                    }
                }
                string cat = "";
                foreach (DataRow dt in dtCategory.Rows)
                {
                    if (dt[1].ToString() == cbox_CategoryDetails.Text)
                    {
                        cat = dt[0].ToString();
                    }
                }
                dtProdukSimpan.Rows[ind][1] = txtbox_NamaDetails.Text;
                dtProdukSimpan.Rows[ind][2] = txtbox_HargaDetails.Text;
                dtProdukSimpan.Rows[ind][3] = txtbox_StockDetails.Text;
                dtProdukSimpan.Rows[ind][4] = cat;
                txtbox_NamaDetails.Text = "";
                txtbox_HargaDetails.Text = "";
                txtbox_StockDetails.Text = "";
                cbox_CategoryDetails.Text = "";
                dtProdukTampil.Clear();
                cbox_FilterProduct.Enabled = false;
                foreach (DataRow simpan in dtProdukSimpan.Rows)
                {
                    dtProdukTampil.Rows.Add(simpan[0], simpan[1], simpan[2], simpan[3], simpan[4]);
                }
            }
        }

        private void btn_RemoveProduct_Click(object sender, EventArgs e)
        {
            bool sama = false;
            int index = 0;
            if (txtbox_NamaDetails.Text == "" || txtbox_HargaDetails.Text == "" || txtbox_StockDetails.Text == "" || cbox_CategoryDetails.Text == "")
            {
                MessageBox.Show("Please choose a product from the table", "Error", MessageBoxButtons.OK, MessageBoxIcon.Error);
            }
            else
            {
                int ind = 0;
                string namabarang = dgv_Products.CurrentRow.Cells[1].Value.ToString();
                for (int i = 0; i < dtProdukSimpan.Rows.Count; i++)
                {
                    if (dtProdukSimpan.Rows[i][1].ToString() == namabarang)
                    {
                        ind = i;
                    }
                }
                dtProdukSimpan.Rows.RemoveAt(ind);
                txtbox_NamaDetails.Text = "";
                txtbox_HargaDetails.Text = "";
                txtbox_StockDetails.Text = "";
                cbox_CategoryDetails.Text = "";
                dtProdukTampil.Clear();
                cbox_FilterProduct.Enabled = false;
                foreach (DataRow simpan in dtProdukSimpan.Rows)
                {
                    dtProdukTampil.Rows.Add(simpan[0], simpan[1], simpan[2], simpan[3], simpan[4]);
                }
            }
        }
    }
}
