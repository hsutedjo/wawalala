﻿namespace TH05_Heidy_Mudita_S
{
    partial class Form_BlinkShop
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Form_BlinkShop));
            this.lbl_Product = new System.Windows.Forms.Label();
            this.cbox_FilterProduct = new System.Windows.Forms.ComboBox();
            this.btn_AllProduct = new System.Windows.Forms.Button();
            this.txtbox_NamaDetails = new System.Windows.Forms.TextBox();
            this.dgv_Products = new System.Windows.Forms.DataGridView();
            this.btn_FilterProduct = new System.Windows.Forms.Button();
            this.lbl_Details = new System.Windows.Forms.Label();
            this.lbl_NamaDetails = new System.Windows.Forms.Label();
            this.lbl_StockDetails = new System.Windows.Forms.Label();
            this.lbl_HargaDetails = new System.Windows.Forms.Label();
            this.lbl_CategoryDetails = new System.Windows.Forms.Label();
            this.cbox_CategoryDetails = new System.Windows.Forms.ComboBox();
            this.txtbox_StockDetails = new System.Windows.Forms.TextBox();
            this.txtbox_HargaDetails = new System.Windows.Forms.TextBox();
            this.btn_AddProduct = new System.Windows.Forms.Button();
            this.btn_RemoveProduct = new System.Windows.Forms.Button();
            this.btn_EditProduct = new System.Windows.Forms.Button();
            this.btn_RemoveCategory = new System.Windows.Forms.Button();
            this.btn_AddCategory = new System.Windows.Forms.Button();
            this.lbl_NamaCategory = new System.Windows.Forms.Label();
            this.txtbox_NamaCategory = new System.Windows.Forms.TextBox();
            this.dgv_Category = new System.Windows.Forms.DataGridView();
            this.lbl_Category = new System.Windows.Forms.Label();
            this.pbox_Sticker = new System.Windows.Forms.PictureBox();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Products)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Sticker)).BeginInit();
            this.SuspendLayout();
            // 
            // lbl_Product
            // 
            this.lbl_Product.AutoSize = true;
            this.lbl_Product.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Product.Location = new System.Drawing.Point(22, 25);
            this.lbl_Product.Name = "lbl_Product";
            this.lbl_Product.Size = new System.Drawing.Size(91, 24);
            this.lbl_Product.TabIndex = 0;
            this.lbl_Product.Text = "Product";
            // 
            // cbox_FilterProduct
            // 
            this.cbox_FilterProduct.BackColor = System.Drawing.SystemColors.ButtonFace;
            this.cbox_FilterProduct.Enabled = false;
            this.cbox_FilterProduct.FormattingEnabled = true;
            this.cbox_FilterProduct.Location = new System.Drawing.Point(350, 47);
            this.cbox_FilterProduct.Name = "cbox_FilterProduct";
            this.cbox_FilterProduct.Size = new System.Drawing.Size(121, 21);
            this.cbox_FilterProduct.TabIndex = 1;
            this.cbox_FilterProduct.SelectedIndexChanged += new System.EventHandler(this.cbox_FilterProduct_SelectedIndexChanged);
            // 
            // btn_AllProduct
            // 
            this.btn_AllProduct.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_AllProduct.Location = new System.Drawing.Point(250, 45);
            this.btn_AllProduct.Name = "btn_AllProduct";
            this.btn_AllProduct.Size = new System.Drawing.Size(44, 23);
            this.btn_AllProduct.TabIndex = 2;
            this.btn_AllProduct.Text = "All";
            this.btn_AllProduct.UseVisualStyleBackColor = false;
            this.btn_AllProduct.Click += new System.EventHandler(this.btn_AllProduct_Click);
            // 
            // txtbox_NamaDetails
            // 
            this.txtbox_NamaDetails.Location = new System.Drawing.Point(78, 431);
            this.txtbox_NamaDetails.Name = "txtbox_NamaDetails";
            this.txtbox_NamaDetails.Size = new System.Drawing.Size(359, 20);
            this.txtbox_NamaDetails.TabIndex = 3;
            // 
            // dgv_Products
            // 
            this.dgv_Products.AllowUserToAddRows = false;
            this.dgv_Products.AllowUserToDeleteRows = false;
            this.dgv_Products.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Products.Location = new System.Drawing.Point(26, 74);
            this.dgv_Products.Name = "dgv_Products";
            this.dgv_Products.ReadOnly = true;
            this.dgv_Products.Size = new System.Drawing.Size(444, 293);
            this.dgv_Products.TabIndex = 4;
            this.dgv_Products.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Products_CellClick);
            // 
            // btn_FilterProduct
            // 
            this.btn_FilterProduct.BackColor = System.Drawing.SystemColors.ControlLight;
            this.btn_FilterProduct.Location = new System.Drawing.Point(300, 45);
            this.btn_FilterProduct.Name = "btn_FilterProduct";
            this.btn_FilterProduct.Size = new System.Drawing.Size(44, 23);
            this.btn_FilterProduct.TabIndex = 5;
            this.btn_FilterProduct.Text = "Filter:";
            this.btn_FilterProduct.UseVisualStyleBackColor = false;
            this.btn_FilterProduct.Click += new System.EventHandler(this.btn_FilterProduct_Click);
            // 
            // lbl_Details
            // 
            this.lbl_Details.AutoSize = true;
            this.lbl_Details.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Details.Location = new System.Drawing.Point(22, 397);
            this.lbl_Details.Name = "lbl_Details";
            this.lbl_Details.Size = new System.Drawing.Size(80, 24);
            this.lbl_Details.TabIndex = 6;
            this.lbl_Details.Text = "Details";
            // 
            // lbl_NamaDetails
            // 
            this.lbl_NamaDetails.AutoSize = true;
            this.lbl_NamaDetails.Location = new System.Drawing.Point(23, 434);
            this.lbl_NamaDetails.Name = "lbl_NamaDetails";
            this.lbl_NamaDetails.Size = new System.Drawing.Size(35, 13);
            this.lbl_NamaDetails.TabIndex = 7;
            this.lbl_NamaDetails.Text = "Nama";
            // 
            // lbl_StockDetails
            // 
            this.lbl_StockDetails.AutoSize = true;
            this.lbl_StockDetails.Location = new System.Drawing.Point(23, 512);
            this.lbl_StockDetails.Name = "lbl_StockDetails";
            this.lbl_StockDetails.Size = new System.Drawing.Size(35, 13);
            this.lbl_StockDetails.TabIndex = 8;
            this.lbl_StockDetails.Text = "Stock";
            // 
            // lbl_HargaDetails
            // 
            this.lbl_HargaDetails.AutoSize = true;
            this.lbl_HargaDetails.Location = new System.Drawing.Point(23, 486);
            this.lbl_HargaDetails.Name = "lbl_HargaDetails";
            this.lbl_HargaDetails.Size = new System.Drawing.Size(36, 13);
            this.lbl_HargaDetails.TabIndex = 9;
            this.lbl_HargaDetails.Text = "Harga";
            // 
            // lbl_CategoryDetails
            // 
            this.lbl_CategoryDetails.AutoSize = true;
            this.lbl_CategoryDetails.Location = new System.Drawing.Point(23, 459);
            this.lbl_CategoryDetails.Name = "lbl_CategoryDetails";
            this.lbl_CategoryDetails.Size = new System.Drawing.Size(49, 13);
            this.lbl_CategoryDetails.TabIndex = 10;
            this.lbl_CategoryDetails.Text = "Category";
            // 
            // cbox_CategoryDetails
            // 
            this.cbox_CategoryDetails.FormattingEnabled = true;
            this.cbox_CategoryDetails.Location = new System.Drawing.Point(78, 456);
            this.cbox_CategoryDetails.Name = "cbox_CategoryDetails";
            this.cbox_CategoryDetails.Size = new System.Drawing.Size(135, 21);
            this.cbox_CategoryDetails.TabIndex = 11;
            // 
            // txtbox_StockDetails
            // 
            this.txtbox_StockDetails.Location = new System.Drawing.Point(78, 509);
            this.txtbox_StockDetails.Name = "txtbox_StockDetails";
            this.txtbox_StockDetails.Size = new System.Drawing.Size(135, 20);
            this.txtbox_StockDetails.TabIndex = 12;
            // 
            // txtbox_HargaDetails
            // 
            this.txtbox_HargaDetails.Location = new System.Drawing.Point(78, 483);
            this.txtbox_HargaDetails.Name = "txtbox_HargaDetails";
            this.txtbox_HargaDetails.Size = new System.Drawing.Size(135, 20);
            this.txtbox_HargaDetails.TabIndex = 13;
            // 
            // btn_AddProduct
            // 
            this.btn_AddProduct.BackColor = System.Drawing.Color.Lime;
            this.btn_AddProduct.Location = new System.Drawing.Point(257, 480);
            this.btn_AddProduct.Name = "btn_AddProduct";
            this.btn_AddProduct.Size = new System.Drawing.Size(62, 45);
            this.btn_AddProduct.TabIndex = 14;
            this.btn_AddProduct.Text = "Add Product";
            this.btn_AddProduct.UseVisualStyleBackColor = false;
            this.btn_AddProduct.Click += new System.EventHandler(this.btn_AddProduct_Click);
            // 
            // btn_RemoveProduct
            // 
            this.btn_RemoveProduct.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveProduct.Location = new System.Drawing.Point(375, 480);
            this.btn_RemoveProduct.Name = "btn_RemoveProduct";
            this.btn_RemoveProduct.Size = new System.Drawing.Size(62, 45);
            this.btn_RemoveProduct.TabIndex = 15;
            this.btn_RemoveProduct.Text = "Remove Product";
            this.btn_RemoveProduct.UseVisualStyleBackColor = false;
            this.btn_RemoveProduct.Click += new System.EventHandler(this.btn_RemoveProduct_Click);
            // 
            // btn_EditProduct
            // 
            this.btn_EditProduct.BackColor = System.Drawing.Color.Yellow;
            this.btn_EditProduct.Location = new System.Drawing.Point(316, 480);
            this.btn_EditProduct.Name = "btn_EditProduct";
            this.btn_EditProduct.Size = new System.Drawing.Size(62, 45);
            this.btn_EditProduct.TabIndex = 16;
            this.btn_EditProduct.Text = "Edit Product";
            this.btn_EditProduct.UseVisualStyleBackColor = false;
            this.btn_EditProduct.Click += new System.EventHandler(this.btn_EditProduct_Click);
            // 
            // btn_RemoveCategory
            // 
            this.btn_RemoveCategory.BackColor = System.Drawing.Color.Red;
            this.btn_RemoveCategory.Location = new System.Drawing.Point(668, 333);
            this.btn_RemoveCategory.Name = "btn_RemoveCategory";
            this.btn_RemoveCategory.Size = new System.Drawing.Size(62, 45);
            this.btn_RemoveCategory.TabIndex = 20;
            this.btn_RemoveCategory.Text = "Remove Category";
            this.btn_RemoveCategory.UseVisualStyleBackColor = false;
            this.btn_RemoveCategory.Click += new System.EventHandler(this.btn_RemoveCategory_Click);
            // 
            // btn_AddCategory
            // 
            this.btn_AddCategory.BackColor = System.Drawing.Color.Lime;
            this.btn_AddCategory.Location = new System.Drawing.Point(609, 333);
            this.btn_AddCategory.Name = "btn_AddCategory";
            this.btn_AddCategory.Size = new System.Drawing.Size(62, 45);
            this.btn_AddCategory.TabIndex = 19;
            this.btn_AddCategory.Text = "Add Category";
            this.btn_AddCategory.UseVisualStyleBackColor = false;
            this.btn_AddCategory.Click += new System.EventHandler(this.btn_AddCategory_Click);
            // 
            // lbl_NamaCategory
            // 
            this.lbl_NamaCategory.AutoSize = true;
            this.lbl_NamaCategory.Location = new System.Drawing.Point(507, 312);
            this.lbl_NamaCategory.Name = "lbl_NamaCategory";
            this.lbl_NamaCategory.Size = new System.Drawing.Size(41, 13);
            this.lbl_NamaCategory.TabIndex = 18;
            this.lbl_NamaCategory.Text = "Nama :";
            // 
            // txtbox_NamaCategory
            // 
            this.txtbox_NamaCategory.Location = new System.Drawing.Point(576, 309);
            this.txtbox_NamaCategory.Name = "txtbox_NamaCategory";
            this.txtbox_NamaCategory.Size = new System.Drawing.Size(154, 20);
            this.txtbox_NamaCategory.TabIndex = 17;
            // 
            // dgv_Category
            // 
            this.dgv_Category.AllowUserToAddRows = false;
            this.dgv_Category.AllowUserToDeleteRows = false;
            this.dgv_Category.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dgv_Category.Location = new System.Drawing.Point(508, 74);
            this.dgv_Category.Name = "dgv_Category";
            this.dgv_Category.ReadOnly = true;
            this.dgv_Category.Size = new System.Drawing.Size(222, 217);
            this.dgv_Category.TabIndex = 21;
            this.dgv_Category.CellClick += new System.Windows.Forms.DataGridViewCellEventHandler(this.dgv_Category_CellClick);
            // 
            // lbl_Category
            // 
            this.lbl_Category.AutoSize = true;
            this.lbl_Category.Font = new System.Drawing.Font("Arial Rounded MT Bold", 15.75F, System.Drawing.FontStyle.Regular, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.lbl_Category.Location = new System.Drawing.Point(506, 25);
            this.lbl_Category.Name = "lbl_Category";
            this.lbl_Category.Size = new System.Drawing.Size(103, 24);
            this.lbl_Category.TabIndex = 22;
            this.lbl_Category.Text = "Category";
            // 
            // pbox_Sticker
            // 
            this.pbox_Sticker.Image = ((System.Drawing.Image)(resources.GetObject("pbox_Sticker.Image")));
            this.pbox_Sticker.Location = new System.Drawing.Point(479, 417);
            this.pbox_Sticker.Name = "pbox_Sticker";
            this.pbox_Sticker.Size = new System.Drawing.Size(276, 228);
            this.pbox_Sticker.SizeMode = System.Windows.Forms.PictureBoxSizeMode.StretchImage;
            this.pbox_Sticker.TabIndex = 23;
            this.pbox_Sticker.TabStop = false;
            // 
            // Form_BlinkShop
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.BackColor = System.Drawing.Color.SandyBrown;
            this.ClientSize = new System.Drawing.Size(785, 630);
            this.Controls.Add(this.pbox_Sticker);
            this.Controls.Add(this.lbl_Category);
            this.Controls.Add(this.dgv_Category);
            this.Controls.Add(this.btn_RemoveCategory);
            this.Controls.Add(this.btn_AddCategory);
            this.Controls.Add(this.lbl_NamaCategory);
            this.Controls.Add(this.txtbox_NamaCategory);
            this.Controls.Add(this.btn_EditProduct);
            this.Controls.Add(this.btn_RemoveProduct);
            this.Controls.Add(this.btn_AddProduct);
            this.Controls.Add(this.txtbox_HargaDetails);
            this.Controls.Add(this.txtbox_StockDetails);
            this.Controls.Add(this.cbox_CategoryDetails);
            this.Controls.Add(this.lbl_CategoryDetails);
            this.Controls.Add(this.lbl_HargaDetails);
            this.Controls.Add(this.lbl_StockDetails);
            this.Controls.Add(this.lbl_NamaDetails);
            this.Controls.Add(this.lbl_Details);
            this.Controls.Add(this.btn_FilterProduct);
            this.Controls.Add(this.dgv_Products);
            this.Controls.Add(this.txtbox_NamaDetails);
            this.Controls.Add(this.btn_AllProduct);
            this.Controls.Add(this.cbox_FilterProduct);
            this.Controls.Add(this.lbl_Product);
            this.Name = "Form_BlinkShop";
            this.Text = "Blink Shop";
            this.Load += new System.EventHandler(this.Form_BlinkShop_Load);
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Products)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dgv_Category)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.pbox_Sticker)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion

        private System.Windows.Forms.Label lbl_Product;
        private System.Windows.Forms.ComboBox cbox_FilterProduct;
        private System.Windows.Forms.Button btn_AllProduct;
        private System.Windows.Forms.TextBox txtbox_NamaDetails;
        private System.Windows.Forms.DataGridView dgv_Products;
        private System.Windows.Forms.Button btn_FilterProduct;
        private System.Windows.Forms.Label lbl_Details;
        private System.Windows.Forms.Label lbl_NamaDetails;
        private System.Windows.Forms.Label lbl_StockDetails;
        private System.Windows.Forms.Label lbl_HargaDetails;
        private System.Windows.Forms.Label lbl_CategoryDetails;
        private System.Windows.Forms.ComboBox cbox_CategoryDetails;
        private System.Windows.Forms.TextBox txtbox_StockDetails;
        private System.Windows.Forms.TextBox txtbox_HargaDetails;
        private System.Windows.Forms.Button btn_AddProduct;
        private System.Windows.Forms.Button btn_RemoveProduct;
        private System.Windows.Forms.Button btn_EditProduct;
        private System.Windows.Forms.Button btn_RemoveCategory;
        private System.Windows.Forms.Button btn_AddCategory;
        private System.Windows.Forms.Label lbl_NamaCategory;
        private System.Windows.Forms.TextBox txtbox_NamaCategory;
        private System.Windows.Forms.DataGridView dgv_Category;
        private System.Windows.Forms.Label lbl_Category;
        private System.Windows.Forms.PictureBox pbox_Sticker;
    }
}

